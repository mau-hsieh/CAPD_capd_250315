<?php
session_start(); // 啟用 session

// 檢查是否已登入，否則重定向至 login.php
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// 資料表名稱變數
$questions_table = "question03";  // 問題表
$score_table = "score03";    // 成績表

// 載入 config.php 並取得資料庫連線資訊
$config = include('config.php');

$servername = $config['servername'];
$username = $config['username'];
$password = $config['password'];
$dbname = $config['dbname'];

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("連接失敗: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];

// 查詢使用者的成績和對應的問題
$sql = "
    SELECT q.question_text, s.user_answer, s.is_correct
    FROM $score_table AS s
    JOIN $questions_table AS q ON s.question_id = q.id
    WHERE s.user_id = ?
    ORDER BY s.session_id, s.question_id";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// 準備變數儲存成績
$scores = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $scores[] = $row;
    }
} else {
    $no_scores = true;
}

$stmt->close();
$conn->close();

?>

<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>查看成績</title>
    <link rel="stylesheet" href="style.css"> <!-- 引用外部 CSS 檔案 -->
</head>
<body>
    <h1>查看成績</h1>

    <?php if (!isset($no_scores)): ?>
        <table>
            <tr>
                <th>問題</th>
                <th>你的答案</th>
                <th>是否正確</th>
            </tr>
            <?php foreach ($scores as $score): ?>
                <tr>
                    <td><?php echo htmlspecialchars($score['question_text']); ?></td>
                    <td><?php echo htmlspecialchars($score['user_answer']); ?></td>
                    <td><?php echo $score['is_correct'] ? '正確' : '錯誤'; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>沒有找到成績記錄。</p>
    <?php endif; ?>

    <a href="index.php" class="back-link">返回使用者列表</a>
</body>
</html>
