<?php
// config.php
return [
    'servername' => 'localhost',
    'username' => 'CAPD',
    'password' => 'DUn2c[/*64pL5zX1',
    'dbname' => 'capd'
];
